### Readme: change standard devolo USB extender firmware to openWRT firmware ###
The firmware update process consists of two parts:
A) Change original firmware into transition firmware
B) Write openWRT bootable binary into flash (kernel and file system combined in one binary) 



### Step A: Change original firmware to transition firmware ###
    This firmware update replaces the original dLAN USB Extender Bootloader to support the new auto-update feature.
    1. Take a second powerline device, with ethernet port like devolo AV200 mini
    2. Pair the powerline devices with each other; e.g. by pushbutton pairing
    3. Connect the second powerline adapter with the ethernet port of the computer
    4. Execute usbextmassupload.exe (transition firmware code "firmware_v100_2012-07-09.dvl" must remain in same directory as usbextmassupload.exe)
    5. Wait until you see the following message block (The update may take up to 10 minutes!):


       UPLOADING : 
       FLASHING  : 
       COMPLETED : 00:0B:3B:DB:39:50 
       FAILED    : 

       -> ALL DEVICES DONE, PLEASE REMOVE AND ATTACH NEXT BATCH OF DEVICES!



    6. Power cycle the dLAN 200 AV usb extender

    

### Step B: Write openWRT bootable binary into flash       ###
### Version: v100                                          ###
### Date: 2012-07-09                                       ###

    ## Important ##
    After updating to v100 the USB Extender hardware only provides an auto-update mechanism via USB pen drive. No further features are supported (no USB to IP translation etc.).
    
    ## Requirements ##
    - FAT32 formatted USB pen drive with one single partition (e.g. without secure partition) 
    - Pen drive volume label: autoupdate (lower case)
    - Name of image:          autoupdate_image (lower case)
    - Max. image size:        less then 7.5 MB

    ## Description of the process ##
    At startup the new bootloader will always test if an USB pen drive is installed in the dLAN USB Extender USB port. 
    If an USB pen drive is plugged, the system will check USB pen drives' volume label and the existence of a valid image.
    In the case that a valid image is found the auto-update process is started and will erase the old firmware including the old devolo configuration. 
    Subsequently the new image will be stored in the flash and the bootloader try to load and start the new firmware.

    ## Hints ##
    - Power cycle the USB Extender before running the auto-update feature
    - The USB LED will indicate the status of the update process. If the LED will not blink (for more than 30 seconds) the update process is finished, except the new firmware will use the USB LED. 
    - Some USB pen drives needs an additional reset, this results in an longer period you have to wait for the update process.




## Known Issues ## 
   - Sometimes it seems some USB pen drives can not be used for the auto-update mechanism. This could be caused by a "wrong" partition table. If a Windows nor Linux formatted pen drive seems to work, double check the partion table using gparted. (It is available at http://gparted.sourceforge.net/ for Windows and Linux). Try to format the pen drive using gparted.

